---
title: Deprecation
titleSuffix: Azure AI services
author: jboback
manager: nitinme
ms.service: azure-ai-anomaly-detector
ms.topic: include
ms.date: 01/18/2024
ms.author: jboback
---

> [!IMPORTANT]
> Starting on the 20th of September, 2023 you won’t be able to create new Anomaly Detector resources. The Anomaly Detector service is being retired on the 1st of October, 2026.