---
title: Face identity input technicals
titleSuffix: Azure AI services
#services: cognitive-services
author: PatrickFarley
manager: nitinme
ms.service: azure-ai-vision
ms.custom:
  - ignite-2023
ms.topic: include
ms.date: 11/07/2023
ms.author: pafarley
---

* The supported input image formats are JPEG, PNG, GIF (the first frame), BMP. 
* The image file size should be no larger than 6 MB.
