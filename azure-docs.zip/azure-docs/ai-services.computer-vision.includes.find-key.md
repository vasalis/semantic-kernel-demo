---
title: "Quickstart: Image Analysis REST API"
titleSuffix: "Azure AI services"
#services: cognitive-services
author: PatrickFarley
manager: nitinme

ms.service: azure-ai-vision
ms.topic: include
ms.date: 08/07/2023
ms.author: pafarley
---

Go to the Azure portal. If the resource you created in the **Prerequisites** section deployed successfully, select **Go to resource** under **Next Steps**. You can find your key and endpoint under **Resource Management** in the **Keys and Endpoint** page. Your resource key isn't the same as your Azure subscription ID.
