---
author: PatrickFarley
ms.service: azure-ai-vision
ms.topic: include
ms.date: 08/01/2023
ms.author: pafarley
---

The Image Analysis SDK for JavaScript is compatible with Windows, Linux, and macOS.
