---
title: Vision SDK license terms
titleSuffix: Azure AI services
description: This page shows links to license terms and third-party notice.
author: PatrickFarley
ms.service: azure-ai-vision
ms.topic: include
ms.date: 12/04/2021
ms.author: pafarley
---

> [!IMPORTANT]
> By installing the Azure AI Vision SDK, you acknowledge its license. For more information, see:
> - <a href="https://aka.ms/azai/vision/license" target="_blank">Microsoft software license terms for the Vision SDK <span class="docon docon-navigate-external x-hidden-focus"></span></a>
> - <a href="https://aka.ms/azai/vision/TPN" target="_blank">Third-party software notices for the Vision SDK<span class="docon docon-navigate-external x-hidden-focus"></span></a>

