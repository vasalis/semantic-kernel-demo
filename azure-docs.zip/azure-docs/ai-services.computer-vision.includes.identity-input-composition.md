---
title: Face identity input technicals
titleSuffix: Azure AI services
#services: cognitive-services
author: PatrickFarley
manager: nitinme
ms.service: azure-ai-vision
ms.custom:
  - ignite-2023
ms.topic: include
ms.date: 11/07/2023
ms.author: pafarley
---

* Some faces might not be recognized because of photo composition, such as:
  * Images with extreme lighting, for example, severe backlighting.
  * Obstructions that block one or both eyes.
  * Differences in hair type or facial hair.
  * Changes in facial appearance because of age.
  * Extreme facial expressions.
